package com.project.samsam.sujin.api;


public class Sido {
	private Integer sidoCode;
	private String sidoNm;
	
	public Sido(Integer sidoCode, String sidoNm) {
		this.sidoCode = sidoCode;
		this.sidoNm = sidoNm;
	}

	public Integer getSidoCode() {
		return sidoCode;
	}

	public void setSidoCode(Integer sidoCode) {
		this.sidoCode = sidoCode;
	}

	public String getSidoNm() {
		return sidoNm;
	}

	public void setSidoNm(String sidoNm) {
		this.sidoNm = sidoNm;
	}
	
	
}
